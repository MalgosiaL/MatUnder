import numpy as np
from sklearn.metrics import mutual_info_score

from IT_methods.utils import conditional_mutual_information


def cmi_maximization(X, Y, num_features):
    n_samples, n_features = X.shape
    selected_features = []

    for _ in range(num_features):
        max_cmim = -np.inf
        best_feature = None

        for feature_idx in range(n_features):
            if feature_idx in selected_features:
                continue

            cmim = mutual_info_score(X[:, feature_idx], Y)

            cmim -= max(
                [
                    mutual_info_score(X[:, feature_idx], X[:, selected_feature])
                    - conditional_mutual_information(
                        X[:, feature_idx], X[:, selected_feature], Y
                    )
                    for selected_feature in selected_features
                ],
                default=0,
            )

            if cmim > max_cmim:
                max_cmim = cmim
                best_feature = feature_idx

        selected_features.append(best_feature)

    return selected_features



def cmi_maximization_stopping(X, Y):
    n_samples, n_features = X.shape
    selected_features = []

    keep_selecting = True

    while keep_selecting:
        max_cmim = -np.inf
        best_feature = None

        for feature_idx in range(n_features):
            if feature_idx in selected_features:
                continue

            cmim = mutual_info_score(X[:, feature_idx], Y)

            additional_info = - max(
                [
                    mutual_info_score(X[:, feature_idx], X[:, selected_feature])
                    - conditional_mutual_information(
                        X[:, feature_idx], X[:, selected_feature], Y
                    )
                    for selected_feature in selected_features
                ],
                default=0,
            )
            cmim += additional_info

            #print(additional_info, feature_idx, selected_features)

            if additional_info < 0:
                continue

            if cmim > max_cmim:
                max_cmim = cmim
                best_feature = feature_idx

        if best_feature is None:
            keep_selecting = False
        else:
            selected_features.append(best_feature)

    return selected_features