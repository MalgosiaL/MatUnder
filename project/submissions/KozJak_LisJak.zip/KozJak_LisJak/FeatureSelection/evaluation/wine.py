from ucimlrepo import fetch_ucirepo
from utils import run_random_forest_experiment, evaluate_all_features, stopping_rule

from IT_methods.utils import equal_frequency_binning


def run_wine():
    wine = fetch_ucirepo(id=109)

    X = wine.data.features
    y = wine.data.targets.iloc[:, 0].to_numpy()

    X = equal_frequency_binning(X, [i for i in range(X.shape[1])], 3)
    X = X.to_numpy()

    stopping_rule(X, y, save_csv="results/features/wine.csv", random_state=1)

    run_random_forest_experiment(X, y, 4, save_csv="results/wine.csv", random_state=35)

    evaluate_all_features(X, y, save_csv="results/wine_all_features_nums.csv", random_state=35)
