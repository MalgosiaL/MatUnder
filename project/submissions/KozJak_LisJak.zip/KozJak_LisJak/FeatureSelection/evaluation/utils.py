import random

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import RFE
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import train_test_split

from IT_methods.CMIM import cmi_maximization, cmi_maximization_stopping
from IT_methods.JMI import joint_mutual_information, joint_mutual_information_stopping
from IT_methods.mRMR import min_redundancy_max_relevance


def train_and_eval(classifier, X_train, Y_train, X_test=None, Y_test=None):
    classifier.fit(X_train, Y_train)
    if X_test is None:
        X_test = X_train
        Y_test = Y_train
    y_pred = classifier.predict(X_test)
    accuracy = accuracy_score(Y_test, y_pred)
    f_score = f1_score(Y_test, y_pred, average="macro")
    metrics = {"accuracy": accuracy, "f1_macro": f_score}
    return classifier, metrics


def run_random_forest_experiment(X, Y, num_features, save_csv=None, random_state=42):
    results = []
    X_train, X_test, y_train, y_test = train_test_split(
        X, Y, test_size=0.2, random_state=random_state
    )

    clf = RandomForestClassifier(n_estimators=100, random_state=random_state)
    clf, metrics = train_and_eval(clf, X_train, y_train, X_test, y_test)
    print(
        f"All features accuracy: {metrics['accuracy'] * 100:.2f}%, F1_macro: {metrics['f1_macro'] * 100:.2f}%\n"
    )
    results.append(
        {
            "Method": "All features",
            "Selected Features": [i for i in range(X.shape[1])],
            "Accuracy": metrics["accuracy"] * 100,
            "F1_macro": metrics["f1_macro"] * 100,
        }
    )

    selected_features = np.argsort(clf.feature_importances_)[::-1][:num_features]
    print("Feature importance selected features:", selected_features)
    clf = RandomForestClassifier(n_estimators=100, random_state=random_state)
    clf, metrics = train_and_eval(
        clf,
        X_train[:, selected_features],
        y_train,
        X_test[:, selected_features],
        y_test,
    )
    print(
        f"Accuracy: {metrics['accuracy'] * 100:.2f}%, F1_macro: {metrics['f1_macro'] * 100:.2f}%\n"
    )
    results.append(
        {
            "Method": "Feature importance",
            "Selected Features": selected_features,
            "Accuracy": metrics["accuracy"] * 100,
            "F1_macro": metrics["f1_macro"] * 100,
        }
    )

    clf = RandomForestClassifier(n_estimators=100, random_state=random_state)
    selector = RFE(clf, n_features_to_select=num_features, step=1)
    selector = selector.fit(X_train, y_train)
    selected_features = np.argwhere(selector.support_).flatten()
    print("RFE selected features:", selected_features)
    clf, metrics = train_and_eval(
        clf,
        X_train[:, selected_features],
        y_train,
        X_test[:, selected_features],
        y_test,
    )
    print(
        f"Accuracy: {metrics['accuracy'] * 100:.2f}%, F1_macro: {metrics['f1_macro'] * 100:.2f}%\n"
    )
    results.append(
        {
            "Method": "RFE",
            "Selected Features": selected_features,
            "Accuracy": metrics["accuracy"] * 100,
            "F1_macro": metrics["f1_macro"] * 100,
        }
    )

    for name, fun in zip(
            ["JMI", "mRMR", "CMIM"],
            [joint_mutual_information, min_redundancy_max_relevance, cmi_maximization],
            # joint_mutual_information
    ):

        selected_features = fun(X, Y, num_features=num_features)
        print(f"{name} selected features:", selected_features)
        clf = RandomForestClassifier(n_estimators=100, random_state=random_state)
        clf, metrics = train_and_eval(
            clf,
            X_train[:, selected_features],
            y_train,
            X_test[:, selected_features],
            y_test,
        )
        print(
            f"Accuracy: {metrics['accuracy'] * 100:.2f}%, F1_macro: {metrics['f1_macro'] * 100:.2f}%\n"
        )
        results.append(
            {
                "Method": name,
                "Selected Features": selected_features,
                "Accuracy": metrics["accuracy"] * 100,
                "F1_macro": metrics["f1_macro"] * 100,
            }
        )

    random.seed(random_state)
    selected_features = random.sample(range(0, X.shape[1]), num_features)
    print("Randomly selected features:", selected_features)
    clf = RandomForestClassifier(n_estimators=100, random_state=random_state)
    clf, metrics = train_and_eval(
        clf,
        X_train[:, selected_features],
        y_train,
        X_test[:, selected_features],
        y_test,
    )
    print(
        f"Accuracy: {metrics['accuracy'] * 100:.2f}%, F1_macro: {metrics['f1_macro'] * 100:.2f}%\n"
    )
    results.append(
        {
            "Method": "Random",
            "Selected Features": selected_features,
            "Accuracy": metrics["accuracy"] * 100,
            "F1_macro": metrics["f1_macro"] * 100,
        }
    )
    results_df = pd.DataFrame(results)
    if save_csv:
        results_df.to_csv(save_csv, index=False)
    return results_df


def evaluate_all_features(X, Y, save_csv=None, random_state=42):
    results = []
    X_train, X_test, y_train, y_test = train_test_split(
        X, Y, test_size=0.2, random_state=random_state
    )

    num_features = X.shape[1]

    clf = RandomForestClassifier(n_estimators=100, random_state=random_state)
    clf, metrics = train_and_eval(clf, X_train, y_train, X_test, y_test)
    selected_features = np.argsort(clf.feature_importances_)[::-1][:num_features]

    for i in range(len(selected_features)):
        features_to_i = selected_features[:(i + 1)]
        print(f"Feature importance selected features:", features_to_i)
        clf = RandomForestClassifier(n_estimators=100, random_state=random_state)
        clf, metrics = train_and_eval(
            clf,
            X_train[:, features_to_i],
            y_train,
            X_test[:, features_to_i],
            y_test,
        )
        print(
            f"Accuracy: {metrics['accuracy'] * 100:.2f}%, F1_macro: {metrics['f1_macro'] * 100:.2f}%\n"
        )
        results.append(
            {
                "Method": 'Feature importance',
                "Features_num": len(features_to_i),
                "Selected Features": features_to_i,
                "Accuracy": metrics["accuracy"] * 100,
                "F1_macro": metrics["f1_macro"] * 100,
            }
        )

    clf = RandomForestClassifier(n_estimators=100, random_state=random_state)
    selector = RFE(clf, n_features_to_select=num_features, step=1)
    selector = selector.fit(X_train, y_train)
    selected_features = np.asarray(range(0, num_features))[np.argsort(selector.ranking_)]#np.argwhere(selector.support_).flatten()
    for i in range(len(selected_features)):
        features_to_i = selected_features[:(i + 1)]
        print(f"RFE selected features:", features_to_i)
        clf = RandomForestClassifier(n_estimators=100, random_state=random_state)
        clf, metrics = train_and_eval(
            clf,
            X_train[:, features_to_i],
            y_train,
            X_test[:, features_to_i],
            y_test,
        )
        print(
            f"Accuracy: {metrics['accuracy'] * 100:.2f}%, F1_macro: {metrics['f1_macro'] * 100:.2f}%\n"
        )
        results.append(
            {
                "Method": 'RFE',
                "Features_num": len(features_to_i),
                "Selected Features": features_to_i,
                "Accuracy": metrics["accuracy"] * 100,
                "F1_macro": metrics["f1_macro"] * 100,
            }
        )

    for name, fun in zip(
            ["JMI", "mRMR", "CMIM"],
            [joint_mutual_information, min_redundancy_max_relevance, cmi_maximization],
    ):
        selected_features = fun(X, Y, num_features=num_features)
        for i in range(len(selected_features)):
            features_to_i = selected_features[:(i + 1)]
            print(f"{name} selected features:", features_to_i)
            clf = RandomForestClassifier(n_estimators=100, random_state=random_state)
            clf, metrics = train_and_eval(
                clf,
                X_train[:, features_to_i],
                y_train,
                X_test[:, features_to_i],
                y_test,
            )
            print(
                f"Accuracy: {metrics['accuracy'] * 100:.2f}%, F1_macro: {metrics['f1_macro'] * 100:.2f}%\n"
            )
            results.append(
                {
                    "Method": name,
                    "Features_num": len(features_to_i),
                    "Selected Features": features_to_i,
                    "Accuracy": metrics["accuracy"] * 100,
                    "F1_macro": metrics["f1_macro"] * 100,
                }
            )

    random.seed(random_state)
    selected_features = random.sample(range(0, X.shape[1]), num_features)

    for i in range(len(selected_features)):
        features_to_i = selected_features[:(i + 1)]
        print(f"Randomly selected selected features:", features_to_i)
        clf = RandomForestClassifier(n_estimators=100, random_state=random_state)
        clf, metrics = train_and_eval(
            clf,
            X_train[:, features_to_i],
            y_train,
            X_test[:, features_to_i],
            y_test,
        )
        print(
            f"Accuracy: {metrics['accuracy'] * 100:.2f}%, F1_macro: {metrics['f1_macro'] * 100:.2f}%\n"
        )
        results.append(
            {
                "Method": 'Random',
                "Features_num": len(features_to_i),
                "Selected Features": features_to_i,
                "Accuracy": metrics["accuracy"] * 100,
                "F1_macro": metrics["f1_macro"] * 100,
            }
        )

    results_df = pd.DataFrame(results)
    if save_csv:
        results_df.to_csv(save_csv, index=False)
    return results_df


def stopping_rule(X, Y, save_csv=None, random_state=42):
    results = []
    X_train, X_test, y_train, y_test = train_test_split(
        X, Y, test_size=0.2, random_state=random_state
    )

    for name, fun in zip(
            ["JMI", "CMIM"],
            [joint_mutual_information_stopping, cmi_maximization_stopping],  # joint_mutual_information
    ):
        if name == 'JMI' or name == 'CMIM':
            selected_features = fun(X, Y)

        print(f"{name} selected features:", selected_features)
        clf = RandomForestClassifier(n_estimators=100, random_state=random_state)
        clf, metrics = train_and_eval(
            clf,
            X_train[:, selected_features],
            y_train,
            X_test[:, selected_features],
            y_test,
        )
        print(
            f"Accuracy: {metrics['accuracy'] * 100:.2f}%, F1_macro: {metrics['f1_macro'] * 100:.2f}%\n"
        )
        results.append(
            {
                "Method": name,
                "Selected Features": selected_features,
                "Accuracy": metrics["accuracy"] * 100,
                "F1_macro": metrics["f1_macro"] * 100,
            }
        )

    results_df = pd.DataFrame(results)
    if save_csv:
        results_df.to_csv(save_csv, index=False)
    return results_df
