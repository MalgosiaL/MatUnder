import argparse
import itertools

import numpy as np
import torch
from aim import Run
from model import VaDE
from sklearn.mixture import GaussianMixture
from torch.nn import functional as F
from torch.optim import Adam
from torch.optim.lr_scheduler import StepLR
from torch.utils.data import ConcatDataset, DataLoader
from torchvision.datasets import MNIST, FashionMNIST
from torchvision.transforms import v2
from tqdm import tqdm
from utils import calc_accuracy

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--dataset", type=str, choices=["mnist", "fashion-mnist"], default="mnist"
    )
    parser.add_argument("--batch_size", type=int, default=1000)
    parser.add_argument("--num_workers", type=int, default=4)
    parser.add_argument("--input_dim", type=int, default=784)
    parser.add_argument("--latent_dim", type=int, default=10)
    parser.add_argument("--n_clusters", type=int, default=10)
    parser.add_argument("--pretrain_n_epochs", type=int, default=50)
    parser.add_argument("--pretrain_lr", type=float, default=0.002)
    parser.add_argument("--n_epochs", type=int, default=200)
    parser.add_argument("--lr", type=float, default=0.002)
    parser.add_argument("--lr_decay_rate", type=int, default=10)
    parser.add_argument("--lr_decay_factor", type=float, default=0.95)
    parser.add_argument("--valid_every", type=int, default=5)
    parser.add_argument("--save_every", type=int, default=50)
    parser.add_argument("--random_seed", type=int, default=2)
    args = parser.parse_args()

    run = Run()
    run["hparams"] = vars(args)

    device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

    torch.manual_seed(args.random_seed)

    match args.dataset:
        case "mnist":
            transform = v2.Compose(
                [
                    v2.ToImage(),
                    v2.ToDtype(torch.float32, scale=True),
                    v2.Lambda(lambda x: torch.flatten(x)),
                ]
            )
            train_dataset = MNIST(
                ".data", transform=transform, train=True, download=True
            )
            valid_dataset = MNIST(
                ".data", transform=transform, train=False, download=True
            )
            dataset = ConcatDataset([train_dataset, valid_dataset])

        case "fashion-mnist":
            transform = v2.Compose(
                [
                    v2.ToImage(),
                    v2.ToDtype(torch.float32, scale=True),
                    v2.Lambda(lambda x: torch.flatten(x)),
                ]
            )
            train_dataset = FashionMNIST(
                ".data", transform=transform, train=True, download=True
            )
            valid_dataset = FashionMNIST(
                ".data", transform=transform, train=False, download=True
            )
            dataset = ConcatDataset([train_dataset, valid_dataset])

    dataloader = DataLoader(
        dataset, batch_size=args.batch_size, num_workers=args.num_workers, shuffle=True
    )
    model = VaDE(args.input_dim, args.latent_dim, args.n_clusters).to(device)

    if args.pretrain_n_epochs > 0:
        print("Pretraining...")

        optimizer = Adam(
            itertools.chain(model.encoder.parameters(), model.decoder.parameters()),
            lr=args.pretrain_lr,
        )

        model.train()
        for i in tqdm(range(args.pretrain_n_epochs), desc="Epochs"):
            for j, (x, y) in enumerate(tqdm(dataloader, desc="Steps", leave=False)):
                x, y = x.to(device), y.to(device)
                mu_z, _ = model.encoder(x)
                x_hat = model.decoder(mu_z)
                loss = torch.mean(
                    torch.sum(F.binary_cross_entropy(x_hat, x, reduction="none"), -1)
                )
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                run.track(
                    loss,
                    name="loss",
                    context={"stage": "pretraining"},
                    epoch=i,
                    step=i * len(dataloader) + j,
                )

        model.encoder.log_sigma2_layer.load_state_dict(
            model.encoder.mu_layer.state_dict()
        )

        print("Fitting GMM...")

        model.eval()
        outputs = []
        with torch.no_grad():
            for x, y in dataloader:
                x, y = x.to(device), y.to(device)
                mu_z, _ = model.encoder(x)
                mu_z = mu_z.detach().numpy(force = True)
                outputs.append(mu_z)
        mu_z = np.concatenate(outputs)

        gmm = GaussianMixture(args.n_clusters, covariance_type="diag")
        gmm.fit(mu_z)

        model.pi_c.data = torch.from_numpy(gmm.weights_).float().to(device)
        model.mu_c.data = torch.from_numpy(gmm.means_).float().to(device)
        model.log_sigma2_c.data = torch.log(torch.from_numpy(gmm.covariances_)).float().to(device)

    print("Training...")

    optimizer = Adam(model.parameters(), lr=args.lr)
    scheduler = StepLR(
        optimizer, step_size=args.lr_decay_rate, gamma=args.lr_decay_factor
    )

    for i in tqdm(range(args.n_epochs), desc="Epochs"):
        run.track(
            scheduler.get_last_lr()[0],
            name="lr",
            context={"stage": "training"},
            epoch=i,
        )

        model.train()
        for j, (x, y) in enumerate(tqdm(dataloader, desc="Steps", leave=False)):
            x, y = x.to(device), y.to(device)
            loss = model.calc_loss(x)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            run.track(
                loss,
                name="loss",
                context={"stage": "training"},
                epoch=i,
                step=i * len(dataloader) + j,
            )

        if i % args.valid_every == 0:
            model.eval()
            outputs = ([], [])
            with torch.no_grad():
                for x, y in dataloader:
                    x, y = x.to(device), y.to(device)
                    y_hat = model.predict(x)
                    y_hat = y_hat.detach().numpy(force = True)
                    y = y.detach().numpy(force = True)
                    outputs[0].append(y_hat)
                    outputs[1].append(y)
            y_hat = np.concatenate(outputs[0])
            y = np.concatenate(outputs[1])
            accuracy = calc_accuracy(y_hat, y)

            run.track(
                accuracy,
                name="accuracy",
                context={"stage": "training"},
                epoch=i,
            )

        if i % args.save_every == 0:
            torch.save(model.state_dict(), f"weights/{run.hash}_{i}.pth")

        scheduler.step()

    print("Finished.")
