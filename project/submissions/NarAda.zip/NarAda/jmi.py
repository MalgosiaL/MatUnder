import numpy as np
from sklearn.metrics import mutual_info_score

from labs_utils import interaction_information


def jmi(X, Y, j, selected_features):
    n = len(selected_features)
    X_j = X[:, j]
    if n == 0:
        return mutual_info_score(X_j, Y)
    sum_term = 0
    for i in range(n):
        sum_term += interaction_information(X_j, X[:, selected_features[i]], Y)
    return mutual_info_score(X_j, Y) + sum_term / n


def jmi_method(X, Y, k=None):
    if k is None:
        k = X.shape[1]
    if k > X.shape[1]:
        raise ValueError(
            f"k has to be smaller than the number of features but given {k}, and the "
            f"number of features is {X.shape[1]}")
    n = X.shape[0]
    m = X.shape[1]

    selected_features = []
    scores = []
    for i in range(k):
        jmi_scores = []
        for j in range(m):
            score = - np.inf
            if j not in selected_features:
                score = jmi(X, Y, j, selected_features)
            jmi_scores.append(score)
        jmi_scores = np.array(jmi_scores)
        selected_feature = np.argmax(jmi_scores)

        selected_features.append(selected_feature)
        scores.append(jmi_scores[selected_feature])

    values = np.arange(len(selected_features))[::-1]
    sorted_values = np.zeros_like(values)
    sorted_values[selected_features] = values
    return sorted_values

