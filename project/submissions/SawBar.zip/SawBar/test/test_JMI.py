import unittest
from Project.feature.JMI import JMISelector
from sklearn.datasets import make_classification


class testJMISelector(unittest.TestCase):
    def test_random_usage(self):
        n_features = 10
        n_informative = 7
        X, y = make_classification(random_state=123, n_features=n_features, n_informative=n_informative, n_redundant=0,
                                   shuffle=False)
        X = (2 * X).round()
        selector = JMISelector().fit(X, y)

        self.assertEqual(selector.n_features_in_, n_features)
        self.assertLessEqual(len(selector.selected_columns), n_features)
