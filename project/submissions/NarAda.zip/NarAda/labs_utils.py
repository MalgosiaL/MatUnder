import numpy as np
from sklearn.metrics import mutual_info_score


def interaction_information(X, Y, Z):
    return conditional_mutual_information(X, Y, Z) - mutual_info_score(X, Y)


def conditional_mutual_information(X, Y, Z):
    cmi = 0
    n = Z.shape[0]
    unique_Z = np.unique(Z)
    for z in unique_Z:
        proba = np.sum(Z == z) / n
        cmi += proba * mutual_info_score(X[Z == z], Y[Z == z])
    return cmi
