import torch
from torch import nn
from torch.nn import functional as F


class Encoder(nn.Module):
    def __init__(self, input_dim, latent_dim):
        super().__init__()
        # architecture as in the paper
        self.common_layers = nn.Sequential(
            nn.Linear(input_dim, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, 2000),
            nn.ReLU(),
        )
        self.mu_layer = nn.Linear(2000, latent_dim)
        self.log_sigma2_layer = nn.Linear(2000, latent_dim)

    def forward(self, x):
        h = self.common_layers(x)
        mu_z = self.mu_layer(h)
        log_sigma2_z = self.log_sigma2_layer(h)
        return mu_z, log_sigma2_z


class Decoder(nn.Module):
    def __init__(self, latent_dim, output_dim):
        super().__init__()
        # architecture as in the paper
        self.common_layers = nn.Sequential(
            nn.Linear(latent_dim, 2000),
            nn.ReLU(),
            nn.Linear(2000, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, output_dim),
            nn.Sigmoid(),  # assuming continuous output
        )

    def forward(self, z):
        x_hat = self.common_layers(z)
        return x_hat


class VaDE(nn.Module):
    def __init__(self, input_dim, latent_dim, n_clusters):
        super().__init__()
        self.encoder = Encoder(input_dim, latent_dim)
        self.decoder = Decoder(latent_dim, input_dim)
        self.pi_c = nn.Parameter(torch.ones(n_clusters) / n_clusters)
        self.mu_c = nn.Parameter(torch.zeros((n_clusters, latent_dim)))
        self.log_sigma2_c = nn.Parameter(torch.zeros((n_clusters, latent_dim)))

    def predict(self, x):
        mu_z, log_sigma2_z = self.encoder(x)
        z = self.sample_z(mu_z, log_sigma2_z)
        gamma_c = self.calc_gamma_c(z)  # why not mu_z intead of z?
        y_hat = torch.argmax(gamma_c, -1)
        return y_hat

    def calc_loss(self, x):
        # equation 12 in the paper
        assert x.ndim == 2  # assuming batched input
        mu_z, log_sigma2_z = self.encoder(x)
        z = self.sample_z(mu_z, log_sigma2_z)
        x_hat = self.decoder(z)
        gamma_c = self.calc_gamma_c(z)
        loss = torch.sum(F.binary_cross_entropy(x_hat, x, reduction="none"), -1)
        loss += (
            torch.sum(
                gamma_c
                * torch.sum(
                    self.log_sigma2_c
                    + torch.exp(torch.unsqueeze(log_sigma2_z, 1) - self.log_sigma2_c)
                    + (torch.unsqueeze(mu_z, 1) - self.mu_c) ** 2
                    / torch.exp(self.log_sigma2_c),
                    -1,
                ),
                -1,
            )
            / 2
        )
        loss -= torch.sum(gamma_c * torch.log(self.pi_c / gamma_c), -1)
        loss -= torch.sum(1 + log_sigma2_z, -1) / 2
        loss = torch.mean(loss)  # averaging over batch
        return loss

    def calc_gamma_c(self, z):
        # equation 16 in the paper
        assert z.ndim == 2  # assuming batched input
        gamma_c = (
            self.pi_c
            * torch.exp(
                -torch.sum(
                    self.log_sigma2_c
                    # omitting a constant
                    + (torch.unsqueeze(z, 1) - self.mu_c) ** 2
                    / torch.exp(self.log_sigma2_c),
                    -1,
                )
                / 2
            )
            + 1e-10  # this is important!
        )
        gamma_c /= torch.unsqueeze(torch.sum(gamma_c, -1), 1)
        return gamma_c

    @staticmethod
    def sample_z(mu_z, log_sigma2_z):
        # equation 14 in the paper
        assert mu_z.ndim == log_sigma2_z.ndim == 2  # assuming batched input
        z = torch.randn_like(mu_z) * torch.exp(log_sigma2_z / 2) + mu_z
        return z
