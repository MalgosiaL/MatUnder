# Variational Deep Embedding

Original article: https://arxiv.org/abs/1611.05148

Original implementation (Keras): https://github.com/slim1017/VaDE

Some other implementations (PyTorch):

- https://github.com/GuHongyang/VaDE-pytorch (118 stars)
- https://github.com/eelxpeng/UnsupervisedDeepLearning-Pytorch (89 stars)
- https://github.com/mori97/VaDE (30 stars)
- https://github.com/baohq1595/vae-dec (6 stars)
- https://github.com/mperezcarrasco/Pytorch-VaDE (3 stars)

---

Use Python 3.11 and preferably a virtual environment.

To install packages use `pip install -r requirements.txt`.

To train models use `python source/train.py`.

To view logs use `aim up`.
