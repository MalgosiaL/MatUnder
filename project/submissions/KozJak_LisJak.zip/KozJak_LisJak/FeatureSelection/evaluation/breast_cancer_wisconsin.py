import pandas as pd
from ucimlrepo import fetch_ucirepo
from utils import run_random_forest_experiment, evaluate_all_features, stopping_rule

from IT_methods.utils import equal_frequency_binning


def run_breast_cancer_wisconsin_diagnostic():
    breast_cancer_wisconsin_diagnostic = fetch_ucirepo(id=17)

    X = breast_cancer_wisconsin_diagnostic.data.features
    y = breast_cancer_wisconsin_diagnostic.data.targets.iloc[:, 0].to_numpy()

    X = equal_frequency_binning(X, [i for i in range(X.shape[1])], 2)
    X = X.to_numpy()

    y[y == "B"] = 0
    y[y == "M"] = 1
    y = y.astype(int)

    stopping_rule(X, y, save_csv="results/features/breast_cancer_wisconsin.csv", random_state=1)

    run_random_forest_experiment(
        X, y, 3, save_csv="results/breast_cancer_wisconsin.csv", random_state=35
    )

    evaluate_all_features(X, y, save_csv="results/breast_cancer_wisconsin_all_features_nums.csv", random_state=35)
