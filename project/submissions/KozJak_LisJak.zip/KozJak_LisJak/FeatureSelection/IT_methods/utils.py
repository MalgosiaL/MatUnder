import numpy as np
import pandas as pd
from sklearn.metrics import mutual_info_score


def conditional_mutual_information(X, Y, Z):
    z_values = np.unique(Z)
    n_z_values = len(z_values)
    n = len(Z)

    cmi = 0

    for i in range(n_z_values):
        z_value_tmp = z_values[i]
        z_condition = Z == z_value_tmp

        X_z = X[z_condition]
        Y_z = Y[z_condition]

        mi_XY_z = mutual_info_score(X_z, Y_z)
        p_z = np.sum(z_condition) / n

        cmi += p_z * mi_XY_z

    return cmi


def equal_width_binning(df, columns, num_bins):
    num_bins = __transform_num_bins_to_list(df, columns, num_bins)
    min_value = df.iloc[:, columns].min().to_numpy()
    max_value = df.iloc[:, columns].max().to_numpy()
    bins = [
        np.linspace(min_value[i], max_value[i], num_bins[i] + 1)
        for i in range(len(columns))
    ]
    for i, col in enumerate(columns):
        df.iloc[:, col] = np.digitize(df.iloc[:, col], bins[i])
    return df


def equal_frequency_binning(df, columns, num_bins):
    num_bins = __transform_num_bins_to_list(df, columns, num_bins)
    quantiles = [np.linspace(0, 1, num_bins[i] + 1) for i in range(len(columns))]
    bins = [
        df.iloc[:, columns[i]].quantile(quantiles[i]).to_numpy()
        for i in range(len(columns))
    ]
    for i, col in enumerate(columns):
        bins[i][0] = float("-inf")
        bins[i][-1] = float("inf")
        df.iloc[:, col] = np.digitize(df.iloc[:, col], bins[i])
    return df


def __transform_num_bins_to_list(df, columns, num_bins):
    if type(num_bins) is str:
        if num_bins == "freedman_diaconis_rule":
            num_bins = [
                find_num_of_bins(df.shape[0], num_bins, df.iloc[:, columns[i]])
                for i in range(len(columns))
            ]
        else:
            num_bins = [find_num_of_bins(df.shape[0], num_bins)] * len(columns)
    else:
        num_bins = [num_bins] * len(columns)
    return num_bins


def find_num_of_bins(n, method, data=None):
    if method == "sturges_rule":
        return int(np.ceil(np.log2(n) + 1))
    elif method == "rice_rule":
        return int(np.ceil(2 * np.cbrt(n)))
    elif method == "freedman_diaconis_rule":
        if data is None:
            raise Exception("Method freedman_diaconis_rule requires data")
        q25, q75 = np.percentile(data, [25, 75])
        iqr = q75 - q25
        bin_width = 2 * iqr / np.cbrt(len(data))
        return int(np.ceil((data.max() - data.min()) / bin_width))
    else:
        raise Exception(
            "Select method 'sturges_rule', 'rice_rule' or 'freedman_diaconis_rule'"
        )


# TODO: remove this main, it was just for testing
if __name__ == "__main__":
    df = pd.read_csv("../datasets/iris.data", header=None)
    num_of_bins, columns = 5, [0, 1, 2, 3]
    df = equal_width_binning(df, columns, num_of_bins)
    print(df)
    print("-" * 40)
    df = pd.read_csv("../datasets/iris.data", header=None)
    num_of_bins, columns = 5, [0, 1, 2, 3]
    df = equal_frequency_binning(df, columns, "freedman_diaconis_rule")
    print(df)
    print(df.shape)
