import pandas as pd
from sklearn.preprocessing import OrdinalEncoder
from ucimlrepo import fetch_ucirepo
from utils import run_random_forest_experiment, evaluate_all_features, stopping_rule

from IT_methods.utils import equal_frequency_binning


def run_bank_marketing():
    bank_marketing = fetch_ucirepo(id=222)

    X = bank_marketing.data.features
    y = bank_marketing.data.targets.iloc[:, 0].to_numpy()

    category_columns = [
        "job",
        "marital",
        "education",
        "default",
        "housing",
        "loan",
        "contact",
        "month",
        "poutcome",
    ]

    enc = OrdinalEncoder()
    X.loc[:, category_columns] = enc.set_params(encoded_missing_value=-1).fit_transform(
        X.loc[:, category_columns]
    )

    pd.options.mode.chained_assignment = None
    for col in category_columns:
        X[col] = pd.to_numeric(X[col])

    X = equal_frequency_binning(X, [0, 1, 5, 9, 10, 11, 13], 4)
    X = X.to_numpy()

    y[y == "no"] = 0
    y[y == "yes"] = 1
    y = y.astype(int)

    stopping_rule(X, y, save_csv="results/features/bank_marketing.csv", random_state=1)

    run_random_forest_experiment(
        X, y, 3, save_csv="results/bank_marketing.csv", random_state=1
    )

    evaluate_all_features(X, y, save_csv="results/bank_marketing_all_features_nums.csv", random_state=35)