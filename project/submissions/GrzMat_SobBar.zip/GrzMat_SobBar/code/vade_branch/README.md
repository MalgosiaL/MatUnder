# Variational Deep Embedding

Original article: https://arxiv.org/abs/1611.05148

Original implementation: https://github.com/slim1017/VaDE

---

To view training logs use `aim up`.
