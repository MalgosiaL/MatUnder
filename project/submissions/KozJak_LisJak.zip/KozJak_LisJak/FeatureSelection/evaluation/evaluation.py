from bank_marketing import run_bank_marketing
from breast_cancer_wisconsin import run_breast_cancer_wisconsin_diagnostic
from sklearn.datasets import make_classification
from student_performance import run_student_performance
from wine import run_wine
from wine_quality import run_wine_quality


def create_artificial_example(random_state=42):
    X, Y = make_classification(
        n_samples=500,
        n_features=30,
        n_informative=5,
        n_redundant=0,
        n_repeated=1,
        n_classes=5,
        n_clusters_per_class=2,
        weights=None,
        flip_y=0.01,
        class_sep=1.0,
        hypercube=True,
        shift=None,
        scale=1.0,
        shuffle=False,
        random_state=random_state,
    )
    return X, Y


def main():
    print(f"{'-'*20} Student performance {'-'*20}")
    run_student_performance()
    print(f"{'-' * 20} Breast Cancer Wisconsin Diagnostic {'-' * 20}")
    run_breast_cancer_wisconsin_diagnostic()
    print(f"{'-' * 20} Wine quality {'-' * 20}")
    run_wine_quality()
    print(f"{'-' * 20} Wine {'-' * 20}")
    run_wine()
    print(f"{'-' * 20} Bank marketing {'-' * 20}")
    run_bank_marketing()

    # # https://archive.ics.uci.edu/dataset/936/national+poll+on+healthy+aging+(npha)
    # df = pd.read_csv("../datasets/NPHA-doctor-visits.csv")
    # Y = df.iloc[:, 0].to_numpy()
    # X = df.iloc[:, 1:].to_numpy()
    # run_random_forest_experiment(
    #     X, Y, 6, save_csv="NPHA-doctor-visits.csv", random_state=42
    # )
    #
    # print("-" * 40)
    #
    # # https://archive.ics.uci.edu/dataset/936/national+poll+on+healthy+aging+(npha)
    # df = pd.read_csv("../datasets/iris.data", header=None)
    # num_of_bins, columns = 4, [0, 1, 2, 3]
    # df = equal_width_binning(df, columns, num_of_bins)
    # Y = pd.factorize(df.iloc[:, df.shape[1] - 1])[0] + 1
    # X = df.iloc[:, : (df.shape[1] - 1)].to_numpy()
    # run_random_forest_experiment(X, Y, 2, random_state=42)
    #
    # print("-" * 40)
    #
    # X, Y = create_artificial_example(random_state=42)
    # num_of_bins = find_num_of_bins(X.shape[0], "sturges_rule")
    # columns = [i for i in range(X.shape[1])]
    # df = pd.DataFrame(X)
    # df = equal_width_binning(df, columns, num_of_bins)
    # X = df.to_numpy()
    # run_random_forest_experiment(X, Y, 5, random_state=42)


if __name__ == "__main__":
    main()
