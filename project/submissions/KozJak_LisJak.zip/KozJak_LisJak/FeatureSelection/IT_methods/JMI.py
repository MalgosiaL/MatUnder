import numpy as np
from sklearn.metrics import mutual_info_score

from IT_methods.utils import conditional_mutual_information


def joint_mutual_information(X, Y, num_features):
    n_samples, n_features = X.shape
    selected_features = []

    for _ in range(num_features):
        max_jmi = -np.inf
        best_feature = None

        for feature_idx in range(n_features):
            if feature_idx in selected_features:
                continue

            jmi = mutual_info_score(X[:, feature_idx], Y)
            for selected_feature in selected_features:
                jmi -= (
                               mutual_info_score(X[:, feature_idx], X[:, selected_feature])
                               - conditional_mutual_information(
                           X[:, feature_idx], X[:, selected_feature], Y
                       )
                       ) / len(selected_features)

            if jmi > max_jmi:
                max_jmi = jmi
                best_feature = feature_idx

        selected_features.append(best_feature)

    return selected_features


def joint_mutual_information_stopping(X, Y):
    n_samples, n_features = X.shape
    selected_features = []

    keep_selecting = True

    while keep_selecting:
        max_jmi = -np.inf
        best_feature = None

        for feature_idx in range(n_features):
            if feature_idx in selected_features:
                continue

            jmi = mutual_info_score(X[:, feature_idx], Y)
            additional_info = 0
            for selected_feature in selected_features:
                additional_info -= (
                                           mutual_info_score(X[:, feature_idx], X[:, selected_feature])
                                           - conditional_mutual_information(
                                       X[:, feature_idx], X[:, selected_feature], Y
                                   )
                                   ) / len(selected_features)

            jmi = jmi + additional_info
            #print(additional_info, feature_idx, selected_features)

            if additional_info < 0:
                continue
            if jmi > max_jmi:
                max_jmi = jmi
                best_feature = feature_idx

        if best_feature is None:
            keep_selecting = False
        else:
            selected_features.append(best_feature)

    return selected_features
