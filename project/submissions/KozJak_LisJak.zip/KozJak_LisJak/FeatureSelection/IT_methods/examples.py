import numpy as np

from IT_methods.CMIM import cmi_maximization
from IT_methods.JMI import joint_mutual_information
from IT_methods.mRMR import min_redundancy_max_relevance

if __name__ == "__main__":
    X = np.array(
        [
            [1, 1, 1, 0, 1, 1, 1],
            [1, 1, 0, 0, 0, 0, 1],
            [1, 0, 1, 0, 1, 1, 0],
            [1, 1, 1, 0, 0, 1, 1],
            [1, 0, 1, 1, 1, 0, 0],
            [0, 1, 1, 0, 0, 1, 1],
            [0, 1, 1, 1, 1, 0, 1],
            [1, 1, 1, 0, 0, 1, 0],
            [0, 0, 0, 0, 1, 0, 1],
            [0, 0, 0, 1, 0, 1, 0],
            [0, 0, 0, 1, 1, 1, 1],
            [0, 1, 0, 1, 0, 0, 1],
            [0, 0, 0, 1, 1, 1, 1],
            [0, 0, 1, 0, 0, 1, 0],
            [0, 0, 0, 1, 1, 0, 1],
            [0, 0, 0, 1, 0, 1, 0],
        ]
    )
    y = np.array([1] * 8 + [0] * 8)

    selected_features = joint_mutual_information(X, y, num_features=6)
    print("JMI selected features:", selected_features)

    selected_features = min_redundancy_max_relevance(X, y, num_features=6)
    print("mRMR selected features:", selected_features)

    selected_features = cmi_maximization(X, y, num_features=6)
    print("CMIM selected features:", selected_features)
