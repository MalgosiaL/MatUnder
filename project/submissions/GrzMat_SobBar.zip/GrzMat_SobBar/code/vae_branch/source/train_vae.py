import argparse
import itertools

import numpy as np
import torch
from aim import Run
from model import VAE
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score
from torch.nn import functional as F
from torch.optim import Adam
from torch.optim.lr_scheduler import StepLR
from torch.utils.data import ConcatDataset, DataLoader
from torchvision.datasets import MNIST, FashionMNIST
from torchvision.transforms import v2
from tqdm import tqdm
from utils import calc_accuracy

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--dataset", type=str, choices=["mnist", "fashion-mnist"], default="mnist"
    )
    parser.add_argument("--batch_size", type=int, default=128)
    parser.add_argument("--num_workers", type=int, default=4)
    parser.add_argument("--input_dim", type=int, default=784)
    parser.add_argument("--latent_dim", type=int, default=10)
    parser.add_argument("--kl_lambda", type=float, default=1.0)
    parser.add_argument("--n_epochs", type=int, default=205)
    parser.add_argument("--lr", type=float, default=0.002)
    parser.add_argument("--lr_decay_rate", type=int, default=10)
    parser.add_argument("--lr_decay_factor", type=float, default=0.95)
    parser.add_argument("--save_every", type=int, default=50)
    parser.add_argument("--valid_every", type=int, default=10)
    parser.add_argument("--random_seed", type=int, default=2)
    args = parser.parse_args()

    run = Run()
    run["hparams"] = vars(args)

    device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

    torch.manual_seed(args.random_seed)

    match args.dataset:
        case "mnist":
            transform = v2.Compose(
                [
                    v2.ToImage(),
                    v2.ToDtype(torch.float32, scale=True),
                    v2.Lambda(lambda x: torch.flatten(x)),
                ]
            )
            train_dataset = MNIST(
                ".data", transform=transform, train=True, download=True
            )
            valid_dataset = MNIST(
                ".data", transform=transform, train=False, download=True
            )
            dataset = ConcatDataset([train_dataset, valid_dataset])

        case "fashion-mnist":
            transform = v2.Compose(
                [
                    v2.ToImage(),
                    v2.ToDtype(torch.float32, scale=True),
                    v2.Lambda(lambda x: torch.flatten(x)),
                ]
            )
            train_dataset = FashionMNIST(
                ".data", transform=transform, train=True, download=True
            )
            valid_dataset = FashionMNIST(
                ".data", transform=transform, train=False, download=True
            )
            dataset = ConcatDataset([train_dataset, valid_dataset])

    dataloader = DataLoader(
        dataset, batch_size=args.batch_size, num_workers=args.num_workers, shuffle=True
    )
    model = VAE(args.input_dim, args.latent_dim, args.kl_lambda).to(device)

    optimizer = Adam(model.parameters(), lr = args.lr)
    scheduler = StepLR(
        optimizer, step_size = args.lr_decay_rate, gamma = args.lr_decay_factor)

    print("Training...")

    for i in tqdm(range(args.n_epochs), desc="Epochs"):
        run.track(
            scheduler.get_last_lr()[0],
            name="lr",
            context={"stage": "training"},
            epoch=i,
        )

        pbar = tqdm(dataloader, desc="Steps", leave=False)

        model.train()
        for j, (x, y) in enumerate(pbar):
            x, y = x.to(device), y.to(device)
            loss = model.calc_loss(x)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            run.track(
                loss,
                name="loss",
                context={"stage": "training"},
                epoch=i,
                step=i * len(dataloader) + j,
            )

            pbar.set_description(f'loss: {loss.item()}')

        if i % args.valid_every == 0:
            model.eval()
            outputs = ([], [])
            
            with torch.no_grad():
                for x, y in dataloader:
                    x, y = x.to(device), y.numpy(force = True)
                    z = model.encode(x).numpy(force = True)
                    outputs[0].append(z)
                    outputs[1].append(y)

            z = np.concatenate(outputs[0])
            y = np.concatenate(outputs[1])
            s_score = silhouette_score(z, y)

            run.track(
                s_score,
                name="silhouette_score",
                context={"stage": "training"},
                epoch=i,
            )


        if i % args.save_every == 0:
            torch.save(model.state_dict(), f"weights/{run.hash}_{i}.pth")

        scheduler.step()

    print("Finished.")
