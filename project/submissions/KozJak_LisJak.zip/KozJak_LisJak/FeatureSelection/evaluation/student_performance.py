import pandas as pd
from ucimlrepo import fetch_ucirepo
from utils import run_random_forest_experiment, evaluate_all_features, stopping_rule

from IT_methods.utils import equal_frequency_binning


def run_student_performance():
    student_performance = fetch_ucirepo(id=320)

    X = student_performance.data.features
    y = student_performance.data.targets

    # y (grades) are from 0 to 20. Let's split it to 2 bins with equal frequencies
    y = equal_frequency_binning(y, [2], 2)
    y = y.iloc[:, 2].to_numpy()

    # Preprocessing of X
    with pd.option_context("future.no_silent_downcasting", True):
        X.loc[:, "school"] = X["school"].replace(["GP", "MS"], [0, 1])
        X.loc[:, "sex"] = X["sex"].replace(["F", "M"], [0, 1])
        X.loc[:, "address"] = X["address"].replace(["U", "R"], [0, 1])
        X.loc[:, "famsize"] = X["famsize"].replace(["LE3", "GT3"], [0, 1])
        X.loc[:, "Pstatus"] = X["Pstatus"].replace(["T", "A"], [0, 1])
        X.loc[:, "guardian"] = X["guardian"].replace(
            ["mother", "father", "other"], [0, 1, 2]
        )
        X.loc[:, "schoolsup"] = X["schoolsup"].replace(["no", "yes"], [0, 1])
        X.loc[:, "famsup"] = X["schoolsup"].replace(["no", "yes"], [0, 1])
        X.loc[:, "paid"] = X["schoolsup"].replace(["no", "yes"], [0, 1])
        X.loc[:, "activities"] = X["schoolsup"].replace(["no", "yes"], [0, 1])
        X.loc[:, "nursery"] = X["schoolsup"].replace(["no", "yes"], [0, 1])
        X.loc[:, "higher"] = X["schoolsup"].replace(["no", "yes"], [0, 1])
        X.loc[:, "internet"] = X["schoolsup"].replace(["no", "yes"], [0, 1])
        X.loc[:, "romantic"] = X["schoolsup"].replace(["no", "yes"], [0, 1])
    X.loc[:, "age"] = X["age"] - 15
    X = X.drop(columns=["Mjob", "Fjob", "reason"])
    X = X.to_numpy()

    stopping_rule(X, y, save_csv="results/features/student_performance.csv", random_state=1)

    run_random_forest_experiment(
        X, y, 8, save_csv="results/student_performance.csv", random_state=42
    )

    evaluate_all_features(X, y, save_csv="results/student_performance_all_features_nums.csv", random_state=35)
