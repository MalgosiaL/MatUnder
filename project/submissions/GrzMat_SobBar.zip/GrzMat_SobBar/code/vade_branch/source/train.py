import argparse
import itertools

import numpy as np
import torch
from aim import Run
from model import VaDE
from sklearn.mixture import GaussianMixture
from torch.nn import functional as F
from torch.optim import Adam
from torch.optim.lr_scheduler import StepLR
from torch.utils.data import ConcatDataset, DataLoader
from torchvision.datasets import MNIST, FashionMNIST
from torchvision.transforms import v2
from tqdm import tqdm
from utils import calc_accuracy


def get_dataloader(dataset, batch_size, num_workers, device):
    match dataset:
        case "mnist":
            transform = v2.Compose(
                [
                    v2.ToImage(),
                    v2.ToDtype(torch.float32, scale=True),
                    v2.Lambda(lambda x: torch.flatten(x)),
                ]
            )
            train_dataset = MNIST(
                root=".data", train=True, download=True, transform=transform
            )
            valid_dataset = MNIST(
                root=".data", train=False, download=True, transform=transform
            )
            dataset = ConcatDataset([train_dataset, valid_dataset])

        case "fashion-mnist":
            transform = v2.Compose(
                [
                    v2.ToImage(),
                    v2.ToDtype(torch.float32, scale=True),
                    v2.Lambda(lambda x: torch.flatten(x)),
                ]
            )
            train_dataset = FashionMNIST(
                root=".data", train=True, download=True, transform=transform
            )
            valid_dataset = FashionMNIST(
                root=".data", train=False, download=True, transform=transform
            )
            dataset = ConcatDataset([train_dataset, valid_dataset])

    dataloader = DataLoader(
        dataset,
        shuffle=True,
        batch_size=batch_size,
        num_workers=num_workers,
        pin_memory=device.type == "cuda",
    )

    return dataloader


def pretrain_epoch(model, dataloader, optimizer, device, run, epoch):
    model.train()
    for x, _ in dataloader:
        x = x.to(device)
        optimizer.zero_grad()
        mu_z, _ = model.encoder(x)
        x_hat = model.decoder(mu_z)
        loss = F.mse_loss(x_hat, x)
        loss.backward()
        optimizer.step()

        run.track(loss, name="pretrain_loss", epoch=epoch)


def fit_gmm(model, dataloader, n_clusters, device, seed):
    model.eval()
    outputs = []
    with torch.no_grad():
        for x, _ in dataloader:
            x = x.to(device)
            mu_z, _ = model.encoder(x)
            mu_z = mu_z.numpy(force=True)
            outputs.append(mu_z)
    mu_z = np.concatenate(outputs)

    gmm = GaussianMixture(n_clusters, covariance_type="diag", random_state=seed).fit(
        mu_z
    )
    model.pi_c.data = torch.from_numpy(gmm.weights_).float().to(device)
    model.mu_c.data = torch.from_numpy(gmm.means_).float().to(device)
    model.log_sigma2_c.data = torch.log(torch.from_numpy(gmm.covariances_).float()).to(
        device
    )


def train_epoch(model, dataloader, device, run, epoch):
    model.train()
    for x, _ in dataloader:
        x = x.to(device)
        optimizer.zero_grad()
        loss = model.calc_loss(x)
        loss.backward()
        optimizer.step()

        run.track(loss, name="train_loss", epoch=epoch)


def valid_epoch(model, dataloader, device, run, epoch):
    model.eval()
    outputs = []
    with torch.no_grad():
        for x, y in dataloader:
            x = x.to(device)
            y_hat = model.predict(x)
            y_hat = y_hat.numpy(force=True)
            y = y.numpy(force=True)
            outputs.append((y_hat, y))
    y_hat = np.concatenate([output[0] for output in outputs])
    y = np.concatenate([output[1] for output in outputs])

    acc = calc_accuracy(y_hat, y)
    run.track(acc, name="valid_accuracy", epoch=epoch)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--experiment", type=str, default="default")
    parser.add_argument("--dataset", type=str, default="mnist")
    parser.add_argument("--batch_size", type=int, default=800)
    parser.add_argument("--num_workers", type=int, default=4)
    parser.add_argument("--input_dim", type=int, default=784)
    parser.add_argument("--latent_dim", type=int, default=10)
    parser.add_argument("--n_clusters", type=int, default=10)
    parser.add_argument("--pretrain_epochs", type=int, default=50)
    parser.add_argument("--pretrain_lr", type=float, default=1e-3)
    parser.add_argument("--epochs", type=int, default=200)
    parser.add_argument("--lr", type=float, default=2e-3)
    parser.add_argument("--lr_scheduler_step_size", type=int, default=10)
    parser.add_argument("--lr_scheduler_gamma", type=float, default=0.95)
    parser.add_argument("--valid_every", type=int, default=10)
    parser.add_argument("--save_every", type=int, default=50)
    parser.add_argument("--seed", type=int, default=123)
    args = parser.parse_args()

    run = Run(experiment=args.experiment)
    run["hparams"] = vars(args)

    torch.manual_seed(args.seed)
    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")

    dataloader = get_dataloader(args.dataset, args.batch_size, args.num_workers, device)
    model = VaDE(args.input_dim, args.latent_dim, args.n_clusters).to(device)

    if args.pretrain_epochs:
        optimizer = Adam(
            itertools.chain(model.encoder.parameters(), model.decoder.parameters()),
            lr=args.pretrain_lr,
        )

        print("Pretraining...")
        for epoch in tqdm(range(args.pretrain_epochs)):
            pretrain_epoch(model, dataloader, optimizer, device, run, epoch)
        model.encoder.log_sigma2_layer.load_state_dict(
            model.encoder.mu_layer.state_dict()
        )

        print("Fitting GMM...")
        fit_gmm(model, dataloader, args.n_clusters, device, args.seed)

    optimizer = Adam(model.parameters(), lr=args.lr)
    scheduler = StepLR(
        optimizer, step_size=args.lr_scheduler_step_size, gamma=args.lr_scheduler_gamma
    )

    print("Training...")
    for epoch in tqdm(range(args.epochs)):
        run.track(scheduler.get_last_lr()[0], name="learning_rate", epoch=epoch)

        train_epoch(model, dataloader, device, run, epoch)

        if (epoch + 1) % args.valid_every == 0 or (epoch + 1) in (1, args.epochs):
            valid_epoch(model, dataloader, device, run, epoch)

        if (epoch + 1) % args.save_every == 0 or (epoch + 1) in (1, args.epochs):
            torch.save(model.state_dict(), f"weights/{run.hash}_{epoch+1}.pth")

        scheduler.step()

    print("Finished.")
