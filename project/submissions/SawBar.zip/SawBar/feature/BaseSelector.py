import abc
from typing import Union, List

import numpy as np
from sklearn.base import BaseEstimator
from sklearn.feature_selection import SelectorMixin
from sklearn.metrics import mutual_info_score


class BaseSelector(abc.ABC, SelectorMixin, BaseEstimator):

    def conditional_mutual_information(self, X, Y, Z):
        z_values = np.unique(Z, axis=0)
        n_z_values = len(z_values)
        if len(n := Z.shape) < 2:
            p = 1
        else:
            n, p = Z.shape
        cmi = 0
        for i in range(n_z_values):
            z_value_tmp = z_values[i]
            z_condition = (Z == z_value_tmp).reshape(-1, p)[:, 0]
            X_z = X[z_condition]
            Y_z = Y[z_condition]
            mi_XY_z = mutual_info_score(X_z, Y_z)
            p_z = np.sum(z_condition) / n
            cmi += p_z * mi_XY_z

        return cmi

    def __init__(self, verbose=False):
        self.selected_columns: Union[List, None] = None
        self.n_features_in_: Union[int, None] = None
        self.verbose = verbose

    @abc.abstractmethod
    def fit(self, X, y):
        pass

    def _get_support_mask(self):
        mask = np.zeros(self.n_features_in_)
        mask[self.selected_columns] = True
        return mask
