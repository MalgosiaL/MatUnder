from ucimlrepo import fetch_ucirepo
from utils import run_random_forest_experiment, evaluate_all_features, stopping_rule

from IT_methods.utils import equal_frequency_binning


def run_wine_quality():
    wine_quality = fetch_ucirepo(id=186)

    X = wine_quality.data.features
    y = wine_quality.data.targets

    X = equal_frequency_binning(X, [i for i in range(X.shape[1])], 3)
    X = X.to_numpy()

    # y (quality) are from 0 to 10. Let's split it to 3 bins with equal frequencies
    y = equal_frequency_binning(y, [0], 3)
    y = y.iloc[:, 0].to_numpy()

    stopping_rule(X, y, save_csv="results/features/wine_quality.csv", random_state=1)

    run_random_forest_experiment(
        X, y, 3, save_csv="results/wine_quality.csv", random_state=35
    )

    evaluate_all_features(X, y, save_csv="results/wine_quality_all_features_nums.csv", random_state=35)

