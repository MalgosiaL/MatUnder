#!/usr/bin/env bash
#SBATCH --partition short
#SBATCH --account=mi2lab-normal
#SBATCH --cpus-per-task=1
#SBATCH --gres=gpu:1
#SBATCH --mem=40G
#SBATCH --time 14:00:00
#SBATCH --job-name=inp_exp
#SBATCH --output=slurm_logs/vade-%A.log

# echo file content to logs
script_path=$(readlink -f "$0")
cat $script_path

# activate env
source /raid/shared/$USER/conda/etc/profile.d/conda.sh
conda activate vade

# run exp
cd /home2/faculty/bsobieski/vade

for SEED in {1..10}; do

    python source/train_vae.py --random_seed $SEED

done