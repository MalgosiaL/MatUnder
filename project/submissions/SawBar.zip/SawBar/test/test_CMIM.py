import unittest
from Project.feature.CMIM import CMIMSelector
from sklearn.datasets import make_classification


class testCMIMSelector(unittest.TestCase):
    def test_random_usage(self):
        n_features_in = 20
        n_features_out = 2
        X, y = make_classification(random_state=123,
                                   n_features=n_features_in,
                                   n_informative=n_features_out,
                                   n_redundant=0,
                                   shuffle=False)
        X = X.round()
        selector = CMIMSelector(max_iter=n_features_in, verbose=True).fit(X, y)

        self.assertEqual(selector.n_features_in_, n_features_in)

    def test_verbosity(self):
        n_features_in = 5
        n_features_out = 2
        X, y = make_classification(random_state=123,
                                   n_features=n_features_in,
                                   n_informative=n_features_out,
                                   shuffle=False)
        X = X.round()
        selector = CMIMSelector(max_iter=n_features_in, verbose=True).fit(X, y)

        self.assertEqual(selector.n_features_in_, n_features_in)

