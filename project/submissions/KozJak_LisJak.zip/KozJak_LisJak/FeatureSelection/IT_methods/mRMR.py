import numpy as np
from sklearn.metrics import mutual_info_score


def min_redundancy_max_relevance(X, Y, num_features):
    n_samples, n_features = X.shape
    selected_features = []

    for _ in range(num_features):
        max_mrmr = -np.inf
        best_feature = None

        for feature_idx in range(n_features):
            if feature_idx in selected_features:
                continue

            mrmr = mutual_info_score(X[:, feature_idx], Y)
            for selected_feature in selected_features:
                mrmr -= mutual_info_score(
                    X[:, feature_idx], X[:, selected_feature]
                ) / len(selected_features)

            if mrmr > max_mrmr:
                max_mrmr = mrmr
                best_feature = feature_idx

        selected_features.append(best_feature)

    return selected_features
