import numpy as np
from scipy.optimize import linear_sum_assignment
from sklearn.metrics import confusion_matrix


def calc_accuracy(y_hat, y):
    # https://smorbieu.gitlab.io/accuracy-from-classification-to-clustering-evaluation/
    cm = confusion_matrix(y, y_hat)
    c = -cm + np.max(cm)
    _, col_ind = linear_sum_assignment(c)
    cm = cm[:, col_ind]
    acc = np.trace(cm) / np.sum(cm)
    return acc
