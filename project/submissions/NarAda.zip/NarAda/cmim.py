import numpy as np
from sklearn.metrics import mutual_info_score

from labs_utils import conditional_mutual_information


def cmim_method(X, Y, k=None):
    print(k)
    if k is None:
        k = X.shape[1]
    if k > X.shape[1]:
        raise ValueError(
            f"k has to be smaller than the number of features but given {k}, and the "
            f"number of features is {X.shape[1]}")
    n = X.shape[0]
    m = X.shape[1]

    selected_features = []
    scores = []
    for i in range(k):
        cmim_scores = []
        # iterate over features
        for j in range(m):
            score = - np.inf
            if j not in selected_features:
                score = cmim(X, Y, j, selected_features)
            cmim_scores.append(score)
        cmim_scores = np.array(cmim_scores)
        selected_feature = np.argmax(cmim_scores)

        selected_features.append(selected_feature)
        scores.append(cmim_scores[selected_feature])
    # print(selected_features)
    # values = np.arange(k)[::-1]
    # sorted_values = np.zeros_like(values)
    # sorted_values[selected_features] = values
    return selected_features
def cmim(X, Y, j, selected_features):
    n = len(selected_features)
    X_j = X[:, j]
    if n == 0:
        return mutual_info_score(X_j, Y)
    scores = []
    for i in range(n):
        scores.append(
            conditional_mutual_information(X_j, Y, X[:, selected_features[i]]))
    return np.min(scores)


