from typing import List, Union

import numpy as np
from sklearn.metrics import mutual_info_score

from Project.feature.BaseSelector import BaseSelector


class JMISelector(BaseSelector):
    def jmi(self, x, y, Xs):
        if Xs.shape[1] == 0:
            return mutual_info_score(x, y)
        return np.mean([self.conditional_mutual_information(x, y, Xs[:, i]) for i in range(Xs.shape[1])])

    def __init__(self, verbose=False):
        super().__init__(verbose)
        self.jmi_scores: Union[List, None] = None

    def fit(self, X, y):
        self.n_features_in_ = X.shape[1]
        selected_columns = []
        jmi_scores = []
        iteration = 0
        columns_left = list(range(self.n_features_in_))
        while len(selected_columns) < self.n_features_in_:
            # get column with the highest JMI and add to selected
            jmis = [self.jmi(X[:, column_idx], y, X[:, selected_columns]) for column_idx in columns_left]
            current_column = np.argmax(jmis)
            if iteration > 0 and jmis[current_column] > jmi_scores[-1]:
                break
            selected_columns += [columns_left.pop(current_column)]
            jmi_scores += [jmis[current_column]]
            iteration += 1
            if self.verbose:
                print(f"Finished iteration {iteration}.")

        self.selected_columns = selected_columns
        self.jmi_scores = jmi_scores
        return self
