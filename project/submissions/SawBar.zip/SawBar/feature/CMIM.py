from typing import List, Union
import numpy as np
from sklearn.metrics import mutual_info_score

from Project.feature.BaseSelector import BaseSelector


class CMIMSelector(BaseSelector):
    # link to paper:
    # https://www.jmlr.org/papers/volume5/fleuret04a/fleuret04a.pdf
    def __init__(self, q_stop=0.75, max_iter=10, verbose=False):
        super().__init__(verbose)
        self.max_iter = max_iter
        self.scores = []
        self.q_stop = q_stop

    def fit(self, X, y):
        self.n_features_in_ = X.shape[1]
        self.scores = []
        # scores
        s = np.array([mutual_info_score(X[:, i], y) for i in range(X.shape[1])])
        selected_columns = []
        remaining_columns = list(range(self.n_features_in_))
        for k in range(self.max_iter):
            i_max = np.argmax(s)
            selected_columns.append(remaining_columns[i_max])
            self.scores += [s[i_max]]
            s = np.delete(s, i_max)
            # break if the second max score is low enough
            if len(s) > 0 and np.max(s) < self.q_stop * self.scores[-1]:
                break
            remaining_columns.pop(i_max)
            for j, i in enumerate(remaining_columns):
                s[j] = min(s[j], self.conditional_mutual_information(X[:, i], y, X[:, selected_columns]))
            if self.verbose:
                print(f"Finished iteration {k}.")
                # print(["%0.2f" % i for i in s])

        self.selected_columns = selected_columns
        return self
